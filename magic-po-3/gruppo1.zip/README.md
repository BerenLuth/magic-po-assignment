*README*

**Project for Object Oriented Programming course 2016, part 3**

**Group for this Project:**

- Fabio Rosada 851772
- Feliks Hibraj 854342
- Federico Fontolan 854230
- Andrea Giacomazzi 854522
 
**How to setup project**

* move to selected folder for repo (for example /Desktop)
* git clone https://BerenLuth@bitbucket.org/BerenLuth/magic-po-3.git
* create new Intellij project inside the git repo folder (for example /Desktop/magic-po-3)

**LINK**

quando metterà la roba su moodle metto i link qua