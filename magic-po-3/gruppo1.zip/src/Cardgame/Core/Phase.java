package Cardgame.Core;

public interface Phase {
    void execute() throws InterruptedException;
}

