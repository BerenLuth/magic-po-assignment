package Cardgame.Core;

// Factory method for Cards
public interface CardConstructor {
    Card create();
}
