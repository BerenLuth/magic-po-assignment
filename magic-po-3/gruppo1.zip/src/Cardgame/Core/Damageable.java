package Cardgame.Core;


public interface Damageable extends GameEntity {
    void inflictDamage(int dmg);
}
