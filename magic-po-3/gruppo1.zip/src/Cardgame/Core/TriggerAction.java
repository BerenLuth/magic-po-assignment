
package Cardgame.Core;


public interface TriggerAction {
    void execute();
}
