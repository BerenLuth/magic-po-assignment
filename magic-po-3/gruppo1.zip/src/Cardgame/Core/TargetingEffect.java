package Cardgame.Core;

public interface TargetingEffect extends Effect {
    void pickTarget();
}
