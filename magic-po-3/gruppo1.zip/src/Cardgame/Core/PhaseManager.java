package Cardgame.Core;



public interface PhaseManager{
    Phases currentPhase();
    Phases nextPhase();
}
