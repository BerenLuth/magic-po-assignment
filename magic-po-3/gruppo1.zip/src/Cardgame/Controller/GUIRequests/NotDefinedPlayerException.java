package Cardgame.Controller.GUIRequests;


public class NotDefinedPlayerException extends RuntimeException {
}
