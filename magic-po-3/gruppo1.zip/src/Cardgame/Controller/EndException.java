package Cardgame.Controller;


public class EndException extends RuntimeException {

    public EndException(){}

}
