package Cardgame.GUI;

/**
 * Created by felix on 20/04/16.
 */
public class MsgException extends RuntimeException{

    public MsgException(){}

    public MsgException(String msg){
        super(msg);
    }
}
