package Cardgame.Cards;

import Cardgame.Controller.GUIRequests.Requests;
import Cardgame.Controller.GUIRequests.TargetRequest;
import Cardgame.Core.*;

import java.util.ArrayList;


public class FalsePeace extends AbstractCard {
    static private final String cardName = "False Peace";
    
    static private StaticInitializer initializer = 
            new StaticInitializer(cardName, new CardConstructor() {
                public Card create() { return new FalsePeace(); }
                } );
    
    public String name() { return cardName; }
    public String type() { return "Sorcery"; }
    public String ruleText() { return "Target player skips his next combat phase"; }
    public String toString() { return name() + " [" + ruleText() +"]";}
    public boolean isInstant() { return false; }

    @Override
    public String getBackground() {
        return "image/False_Peace.jpg";
    }

    private class FalsePeaceEffect extends AbstractCardEffect implements TargetingEffect {
        Player target;
        
        public FalsePeaceEffect(Player p, Card c) { super(p,c); }
        public boolean play() {
            pickTarget();
            return super.play();
        }
        
        public String toString() {
            if (target==null) return super.toString() + " (no target)";
            else return name() + " [" + target.name() + " skips his next combat phase]";
        }
        
        public void pickTarget() {
            /*CardGame.instance.getModel().sendToModel( owner.name() + ": choose target for " + name() );
            CardGame.instance.getModel().sendToModel("1) " + CardGame.instance.getPlayer(0).name());
            CardGame.instance.getModel().sendToModel("2) " + CardGame.instance.getPlayer(1).name());
            */

            ArrayList<Player> players = new ArrayList<>();
            players.add(CardGame.instance.getPlayer(0));
            players.add(CardGame.instance.getPlayer(1));

            TargetRequest request = new TargetRequest(players,1);
            Requests.instance.addRequest(request);
            try {
                int idx = Requests.instance.getResult().get(0);
                if (idx < 0 || idx > 1) target = null;
                else target = CardGame.instance.getPlayer(idx);
            }catch (InterruptedException e){
                target = null;
            }
        }
        
        public void resolve() {
            if (target!=null)
                target.setPhase(Phases.COMBAT, new SkipPhase(Phases.COMBAT));
        }
    }

    public Effect getEffect(Player owner) { 
        return new FalsePeaceEffect(owner, this); 
    }
}
